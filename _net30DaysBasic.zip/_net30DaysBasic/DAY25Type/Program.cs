﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY25Type
{
    class Program
    {
        static void Main(string[] args)
        {
            var memberType = typeof(Member);
            var memberMembers = memberType.GetMembers();
            var memberPropertys = memberType.GetProperties();
            var memberMethods = memberType.GetMethods();
        }
        class Member
        {
            public int ID { get; set; }
            public string Name { get; set; }
            public string Phone;
            public void Print() { }
        }
    }
}
