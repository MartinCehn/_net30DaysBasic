﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY19GenericCollectionCategory
{
    class Program
    {
        static void Main(string[] args)
        {
            var list = new List<Member>();
            list.Add(new Member() { ID = 6 });
            list.Add(new Member() { ID = 7 });
            list.Add(new Member() { ID = 4 });
            list.Sort();
            list.Sort((x, y) => { return -x.ID.CompareTo(y.ID); });
        }
    }
    class Member : IComparable
    {
        public int ID;
        public int CompareTo(object obj) => this.ID.CompareTo(((Member)obj).ID);
    }
}
