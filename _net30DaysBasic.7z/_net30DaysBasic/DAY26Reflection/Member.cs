﻿namespace DAY26Reflection
{
    internal class Member
    {
    }
}