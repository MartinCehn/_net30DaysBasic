﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY13Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            Test test = new Test();
            test.Print();
            Interface1 interface1 = new Test();
            interface1.Print();
            Interface2 interface2 = new Test();
            interface2.Print();
            Console.ReadKey();
        }
    }
    interface Interface1
    {
        void Print();
    }
    interface Interface2
    {
        void Print();
    }
    class Test : Interface1, Interface2
    {
        public void Print()
        {
            Console.WriteLine("我是 Test 的 Print");
        }
        void Interface1.Print()
        {
            Console.WriteLine("我是 Interface1 的 Print");
        }
        void Interface2.Print()
        {
            Console.WriteLine("我是 Interface2 的 Print");
        }
    }
}
