﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day27Attributes
{
    class Program
    {
        public static object MyAttribute { get; private set; }

        static void Main(string[] args)
        {
            //var members = new List<Member>() {
            //new Member () { ID = 0, Name = "Mio" },
            //new Member () { ID = 1, Name = "Miffy" },
            //new Member () { ID = 2, Name = "Lulu" },
            //new Member () { ID = 3, Name = "NekoSan" },
            //new Member () { ID = 3, Name = "MooDoooooooooooooooooo" }
            //};

            //foreach (var member in members)
            //{
            //    Console.WriteLine(value: $"Name = {member.Name}, IsValid = {MyAttribute.IsValid(member, "Name")}");
            //}
        }
    }
}
