﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY21Iterator
{
    class Program
    {
        static void Main(string[] args)
        {
            Node<int> nodes = new Node<int>(2);
            nodes.Next = new Node<int>(6);
            foreach (var n in nodes)
            {
                Console.WriteLine(n);
            }
        }
    }
    class Node<T> : IEnumerable<T>
    {
        public Node()
        {
            Value = default(T);
            Next = null;
        }
        public Node(T value)
        {
            Value = value;
            Next = null;
        }
        public T Value;
        public Node<T> Next;
        public IEnumerator<T> GetEnumerator()
        {
            var temp = this;
            while (temp != null)
            {
                yield return temp.Value;
                temp = temp.Next;
            }
        }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }

}
