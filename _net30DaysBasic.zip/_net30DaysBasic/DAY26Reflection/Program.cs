﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DAY26Reflection
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    var memberType = typeof(Member);
        //    var member = new Member() { ID = 1, Name = "Miffy" };

        //    memberType.InvokeMember("Print", BindingFlags.InvokeMethod, null, new Member(), null);
        //    memberType.InvokeMember("Print", BindingFlags.InvokeMethod, null, member, null);
        //    memberType.InvokeMember("PrintWithMessage", BindingFlags.InvokeMethod, null, member, new Object[] { "s" });
        //    memberType.InvokeMember("Name", BindingFlags.SetProperty, null, member, new Object[] { "Lulu" });
        //    var memberName = memberType.InvokeMember("Name", BindingFlags.GetProperty, null, member, null);
        //}
        //class Member
        //{
        //    public int ID { set; get; } = 0;
        //    public string Name { set; get; } = "Mio";
        //    public void Print() { Console.WriteLine($"ID = {ID}, Name = {Name}"); }
        //    public void PrintWithMessage(string message) { Console.WriteLine($"ID = {ID}, Name = {Name}, Message = {message}"); }
        //}

        //GetValue
        //var member = new Member() { ID = 1, Name = "Miffy" };
        //var memberType = typeof(Member);
        //var memberProperties = memberType.GetProperties();
        //    foreach (var property in memberProperties) {
        //    var value = property.GetValue(member, null);

        //SetValue
        //var member = new Member() { ID = 1, Name = "Miffy" };
        //var memberType = typeof(Member);
        //var memberProperties = memberType.GetProperties();

        //foreach (var property in memberProperties) {
        //if (property.Name == "Name")
        //property.SetValue(member, "NekoSan");
        //}
        //}

        //Invoke
        //var member = new Member() { ID = 1, Name = "Miffy" };
        //var memberType = typeof(Member);
        //var memberMethods = memberType.GetMethods();

        //foreach (var method in memberMethods) {
        //if (method.Name == "Print")
        //    method.Invoke(member, null);
        //}
    }
}
