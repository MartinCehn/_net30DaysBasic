﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAY24DateTime
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //建立一個 DateTime
            //var today = DateTime.Today;
            //var now = DateTime.Now;

            //DateTime 屬性
            //var now = DateTime.Now;
            //int year = now.Year;
            //int month = now.Month;
            //int day = now.Day;
            //int hour = now.Hour;
            //int minute = now.Minute;
            //int second = now.Second;
            //int millisecond = now.Millisecond;
            //DayOfWeek dayOfWeek = now.DayOfWeek;
            //int dayOfYear = now.DayOfYear;

            //Add
            //var now = DateTime.Now;
            //var tomorrow = now.AddDays(1);
            //var yesterday = now.AddDays(-1);
            //var add1hour = now.AddHours(1);

            //Subtract
            //var startTime = DateTime.Now;

            // do something...
            //System.Threading.Thread.Sleep(2 * 1000);

            //var endTime = DateTime.Now;
            //var spentTime = endTime.Subtract(startTime);
            //var totalSecond = spentTime.TotalSeconds;

            //DateTime 轉換成字串
            //var monthYearDay = DateTime.Now.ToString("MM/yyyy/dd");
        }
    }
}
