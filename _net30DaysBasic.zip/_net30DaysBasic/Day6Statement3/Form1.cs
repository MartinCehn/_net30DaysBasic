﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day6Statement3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //9*9-1
            //for (int i = 1; i <= 9; i++) {
            //    for (int j = 1; j <= 9; j++) {
            //        Console.Write($"{i} * {j} = {i * j}\t");
            //    }
            //    Console.Write("\n");
            //}

            //9*9-2 using  break to Separation
            //for (int i = 1; i <= 9; i++)
            //{
            //    for (int j = 1; j <= 9; j++)
            //    {
            //        if (j == 6) break;
            //        Console.Write($"{i} * {j} = {i * j}\t");
            //    }
            //    Console.Write("\n");
            //}

            //continue
            //for (int i = 1; i <= 9; i++)
            //{
            //    for (int j = 1; i <= 9; j++)
            //    {
            //        if (j == 5) continue;
            //        Console.WriteLine($"{i}*{j}={i * j}\t");
            //    }
            //    Console.WriteLine("\n");
            //}

            
        }
    }
}
