﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAY22LINQqueryExpression
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //Select
            //            var members = new List<Member>() {
            //  new Member () { ID = 0, Name = "Mio" },
            //  new Member () { ID = 1, Name = "Miffy" },
            //  new Member () { ID = 2, Name = "Lulu" },
            //  new Member () { ID = 3, Name = "NekoSan" }
            //};

            //            var names = members
            //              .Select(x => x.Name);
            //            var membersAddProperty = members
            //              .Select(x =>
            //               new {
            //                    ID = x.ID,
            //                    Name = x.Name,
            //                    IDName = $"ID = {x.ID}, Name = {x.Name}"
            //                });

            //Where
            //            var members = new List<Member>() {
            //  new Member () { ID = 0, Name = "Mio" },
            //  new Member () { ID = 1, Name = "Miffy" },
            //  new Member () { ID = 2, Name = "Lulu" },
            //  new Member () { ID = 3, Name = "NekoSan" }
            //};

            //            var membersNameContainsMi = members
            //              .Where(x => x.Name.Contains("Mi"));

            //Count
            //var members = new List<Member>() {
            //    new Member () { ID = 0, Name = "Mio" },
            //    new Member () { ID = 1, Name = "Miffy" },
            //    new Member () { ID = 2, Name = "Lulu" },
            //    new Member () { ID = 3, Name = "NekoSan" }
            //};
            //var membersCount = members
            //    .Count();

            //OrderBy
            int[] scores = new int[] { 97, 92, 81, 60 };
            var scoresAddNoOrderByScore = scores
              .Select((x, y) => new { score = x, No = y })
              .OrderBy(x => x.score);
        }
    }
}
