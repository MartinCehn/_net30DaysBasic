﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY14Class3
{
    class Program
    {
        static void Main(string[] args)
        {
            Member member = new Member(1, "Mio");
            member.Print();
            Memberc memberc = new Memberc();
            memberc.Print();
        }
    }
    struct Member
    {

        public Member(int id, string name)
        {
            ID = id;
            Name = name;
        }
        public int ID { get; }
        public string Name { get; }
        public void Print()
        {
            Console.WriteLine($"ID: {ID}, Name: {Name}");
            Console.ReadKey();
        }
    }
    class Memberc
    {
        public Memberc() { }
        public Memberc(int id, string name)
        {
            ID = id;
            Name = name;
        }
        public int ID { get; } = 1;
        public string Name { get; } = "Mio";
        public void Print()
        {
            Console.WriteLine($"ID: {ID}, Name: {Name}");
            Console.ReadKey();
        }
    }
}
