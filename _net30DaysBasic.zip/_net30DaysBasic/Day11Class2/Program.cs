﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day11Class2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            int i2 = i.Add2n(6);
            Console.WriteLine($"i: {i}, i2: {i2}");
            Console.ReadKey();
        }
    }

    static class MyExtensions
    {
        public static int Add2n(this int number, int n)
        {
            return number + 2 * n;
        }
    }
}
