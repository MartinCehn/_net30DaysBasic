﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAY23LINQqueryExpression2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //Take 
            //int[] scores = new int[] { 97, 92, 81, 60 };
            //var scoresTakeTop3 = scores.Take(3);

            //TakeLast
            //int[] scores = new int[] { 97, 92, 81, 60 };
            //var scoresTakeLast3 = scores.TakeLast(3);

            //Skip
            //int[] scores = new int[] { 97, 92, 81, 60 };
            //var scoresSkipTop3 = scores.Skip(3);

            //SkipLast
            //int[] scores = new int[] { 97, 92, 81, 60 };
            //var scoresSkipLast3 = scores.SkipLast(3);

            //First
            //int[] scores = new int[] { 97, 92, 81, 60 };
            //var scoresFirst = scores.First();
            //var scoresFirstLessThan90 = scores.First(x => x < 90);

            //FirstOrDefault
            //int[] scores = new int[] { 97, 92, 81, 60 };
            //var scoresFirstMoreThan900 = scores.FirstOrDefault(x => x > 900);

            //SingleOrDeafault
            //int[] scores = new int[] { 97, 92, 81, 60 };
            //var score = scores.SingleOrDefault(x => x > 900);

            //Any
            //int[] scores = new int[] { 97, 92, 81, 60 };
            //var isScoresAny = scores.Any();
            //var isScoresAnyMoreThan77 = scores.Any(x => x > 77);

            //All
            //int[] scores = new int[] { 97, 92, 81, 60 };
            //var isScoresAllMoreThan70 = scores.All(x => x > 70);

            //Contains
            //int[] scores = new int[] { 97, 92, 81, 60 };
            //var scoresContains900 = scores.Contains(900);

            //Join
            //int[] scores = new int[] { 97, 92, 81, 60 };

            //var members = new List<Member>() {
            //  new Member () { ID = 0, Name = "Mio" },
            //  new Member () { ID = 1, Name = "Miffy" },
            //  new Member () { ID = 2, Name = "Lulu" },
            //  new Member () { ID = 3, Name = "NekoSan" }
            //};

            //var scoresAddNo = scores
            //  .Select((x, y) => new { score = x, No = y });

            //var scoresJoinMember = scoresAddNo
            //  .Join(members,
            //    score => new { ID = score.No },
            //    member => new { ID = member.ID },
            //    (score, member) => new {
            //        ID = score.No,
            //        Name = member.Name,
            //        Score = score.score
            //    });

            //Group By
            //var members = new List<Member>() {
            //  new Member () { ID = 0, Name = "Mio" },
            //  new Member () { ID = 1, Name = "Miffy" },
            //  new Member () { ID = 2, Name = "Lulu" },
            //  new Member () { ID = 3, Name = "NekoSan" }
            //};

            //foreach (var group in members.GroupBy(x => x.Name.First()))
            //{
            //    Console.WriteLine(group.Key);
            //    foreach (var member in group)
            //    {
            //        Console.WriteLine($"\tID = {member.ID}, Name = {member.Name}");
            //    }
            //}
        }
    }
}
