﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY9statement_4
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                TestThrow();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ex.Message : {ex.Message}");
                Console.WriteLine($"ex.Source : {ex.Source}");
                Console.WriteLine($"ex.StackTrace : {ex.StackTrace}");
            }
            finally
            {
                Console.ReadKey();
            }
        }
        static void TestThrow()
        {
            throw new Exception("QQ");
        }
    }
}
