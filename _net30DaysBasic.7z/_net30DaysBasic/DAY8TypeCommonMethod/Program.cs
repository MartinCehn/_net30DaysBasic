﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY8TypeCommonMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            //Parse
            //int a1 = int.Parse("16");
            //Console.Write(a1);
            //Console.ReadKey();


            //判斷輸入是否為數字
            //string input = Console.ReadLine();
            //if (int.TryParse(input, out int number))
            //{
            //    Console.WriteLine($"你輸入的是數字{number}");
            //}
            //else {
            //    Console.WriteLine("你輸入得不是數字");
            //}
            //Console.ReadKey();

            //ToString
            //int number = 516;
            //string curryency = number.ToString("C");
            //Console.WriteLine(curryency);

            //string percent = number.ToString("P");
            //Console.WriteLine(percent);

            //string hex = number.ToString("X");
            //Console.WriteLine(hex);
            //Console.ReadKey();

            //Format
            //string a1 = "333";
            //string a2 = "444";
            //string a3 = string.Format("a1={0},a2={1}", a1, a2);
            //Console.WriteLine(a3);
            //Console.ReadLine();

            //Contains
            //string str1 = "ABC";
            //bool b1 = str1.Contains("BC");
            //bool b2 = str1.Contains("CB");
            //Console.WriteLine(b1);
            //Console.WriteLine(b2);
            //Console.ReadKey();

            //PadLeft & PadRight
            //string strL = "345".PadLeft(3, '0');
            //Console.WriteLine(strL);
            //string strR = "456".PadRight(4, '1');
            //Console.WriteLine(strR);

            //string str = "516".PadLeft(5, '0');
            //Console.WriteLine(str); // 00516
            //Console.ReadKey();

            //Replace 取代字串內容
            //string str = "123".Replace("1", "一")
            //                .Replace("2", "二")
            //                .Replace("3", "三");
            //Console.WriteLine(str);
            //Console.ReadKey();

            //Split
            //"stringsplit".Split(new char[] { 's' }, 1);
            //"stringsplit".Split(new char[] { 's' }, 2); // {"","tringsplit"}
            //"stringsplit".Split(new char[] { 's' }, 3); // {"","tring","plit"}

            //Substring
            //string str = "123456789".Substring(1, 5);
            //Console.WriteLine(str);
            //Console.ReadKey();
            //string str = "123456789".Substring(2);
            //Console.WriteLine(str);
            //Console.ReadKey();

            //Trim
            //string str = "61234567896".Trim('6');
            //Console.WriteLine(str);
            //Console.ReadKey();
            //TrimStart 只移除開頭字元
            //TrimEnd 只移除結尾字元
        }
    }
}
