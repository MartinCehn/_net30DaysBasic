﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day4Statement1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //if-else
            int score = 75;
            if (score < 90) // 分數低於 90
                Console.WriteLine("得到 B");
            else if (score < 80) // 分數低於 80
                Console.WriteLine("得到 C");
            else if (score < 70) // 分數低於 70
                Console.WriteLine("得到 D");
            else if (score < 60) // 分數低於 60
                Console.WriteLine("不及格的 F");
            else                 // 不低於 60 70 80 90 的分數，一樣等於 >= 90
                Console.WriteLine("得到 A");

            //switch-case
            int a = 6;
            switch (a) {
                case 5:
                    Console.WriteLine("a!=所以不執行");
                    break;
                case 6:
                    Console.WriteLine("a==所以執行");
                    break;
            }
        }
    }
}
