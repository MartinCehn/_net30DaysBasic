﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY18Generic
{
    class Program
    {
        static void Main(string[] args)
        {
            Node<int, int> head = new Node<int, int>();
            Node<int, int> node = new Node<int, int>(1, 6, head);
            Node<string, int> head2 = new Node<string, int>();
            Node<string, int> node2 = new Node<string, int>("Mio", 2, head2);
        }
    }
    class Node<T, U>
    {
        public Node()
        {
            Value = default(T);
            Value2 = default(U);
            Next = null;
        }
        public Node(T value, U value2, Node<T, U> next)
        {
            Value = value;
            Value2 = value2;
            Next = next;
        }
        T Value;
        U Value2;
        Node<T, U> Next;
    }
}
