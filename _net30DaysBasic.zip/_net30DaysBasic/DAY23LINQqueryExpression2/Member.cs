﻿namespace DAY23LINQqueryExpression2
{
    internal class Member
    {
        public Member()
        {
        }

        public int ID { get; set; }
        public string Name { get; set; }
    }
}