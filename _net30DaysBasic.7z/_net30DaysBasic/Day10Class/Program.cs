﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day10Class
{
    class Program
    {
        static void Main(string[] args)
        {
            Member member = new Member(1, "米歐");
            member.Print();
        }
        public class Member
        {
            int id;
            string name;
            public Member(int id, string name)
            {
                this.id = id;
                this.name = name;
            }
            public void Print()
            {
                Console.WriteLine($"ID: {id}, Name: {name}");
                Console.ReadKey();
            }
        }

        //多載
        //static void Main(string[] args)
        //{
        //    int t1 = Add(1, 2);
        //    int t2 = Add(1, 2, 3);
        //    string t3 = Add("A", "B");
        //}
        //static int Add(int i1, int i2)
        //{
        //    return i1 + i2;
        //}
        //static int Add(int i1, int i2, int i3)
        //{
        //    return i1 + i2 + i3;
        //}
        //static string Add(string str1, string str2)
        //{
        //    return str1 + str2;
        //}
    }
}
