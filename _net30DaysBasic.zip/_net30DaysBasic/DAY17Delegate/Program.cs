﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY17Delegate
{
    class Program
    {
        //具名函式
        //static void Main(string[] args)
        //{
        //    MyDelegate d;
        //    d = new MyDelegate(add);
        //    var v = d(1, 2); 
        //    Console.WriteLine(v);
        //    d = new MyDelegate(subtract);
        //    v = d(2, 1); 
        //    Console.WriteLine(v);
        //    Console.ReadKey();
        //}
        //public delegate int MyDelegate(int x, int y);
        //public static int add(int a, int b)
        //{
        //    return a + b;
        //}
        //public static int subtract(int a, int b)
        //{
        //    return a - b;
        //}

        //匿名函式
        //static void Main(string[] args)
        //{
        //    MyDelegate d;
        //    d = delegate (int x, int y) {
        //        return x + y;
        //    };
        //    var v = d(1, 2); // 1 + 2 = 3
        //    Console.WriteLine(v);
        //    d = delegate (int x, int y) {
        //        return x - y;
        //    };
        //    v = d(2, 1); // 2 - 1 = 1
        //    Console.WriteLine(v);
        //    Console.ReadKey();
        //}
        //public delegate int MyDelegate(int x, int y);

        //Lambda
        //static void Main(string[] args)
        //{
        //    MyDelegate d;
        //    d = (int x, int y) => { return x + y; };
        //    var v = d(1, 2); // 1 + 2 = 3
        //    Console.WriteLine(v);
        //    d = (x, y) => x - y;
        //    v = d(2, 1); // 2 - 1 = 1
        //    Console.WriteLine(v);
        //    Console.ReadKey();
        //}
        //public delegate int MyDelegate(int x, int y);

        //Action
        //static void Main(string[] args)
        //{
        //    Action<string> action = action1;
        //    action("123"); // 123
        //    action = action2;
        //    action("Mio"); // Hi Mio
        //}
        //public static void action1(string a)
        //{
        //    Console.WriteLine(a);
        //}
        //public static void action2(string a)
        //{
        //    Console.WriteLine("Hi " + a);
        //    Console.ReadKey();
        //}

        //Func
        //static void Main(string[] args)
        //{
        //    Func<int> func = func1;
        //    Console.WriteLine(func()); 
        //    Console.ReadKey();
        //}
        //public static int func1()
        //{
        //    return 0;
        //}

        //Func -Lambda 
        //static void Main(string[] args)
        //{
        //    Func<int> func = () => 0;
        //    Console.WriteLine(func()); // 0
        //    Func<int, int, string> func2 = (a, b) => (a + b).ToString();
        //    Console.WriteLine(func2(1, 2)); // 1 + 2 = 3
        //    Console.ReadKey();
        //}

        //Predicate
        //static void Main(string[] args)
        //{
        //    Predicate<int> predicate = predicate1;
        //    Console.WriteLine(predicate(0)); // True
        //    Console.ReadKey();
        //}
        //public static bool predicate1(int a)
        //{
        //    return a == 0;
        //}

        //
    }
}
