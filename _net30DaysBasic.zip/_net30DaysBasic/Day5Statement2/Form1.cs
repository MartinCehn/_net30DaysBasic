﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day5Statement2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //for迴圈
            for (int a = 1; a <= 5; a++)
            {
                Console.WriteLine(a);
            }

            //for-array
            int[] b = new int[3] { 1, 2, 3 };
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine(b[i]);
            }

            //foreach
            int[] numbers = { 1, 2, 3 };
            foreach (int i in numbers)
            {
                Console.WriteLine(i);
            }

            //do-while
            int c = 1;
            do
            {
                Console.WriteLine(c++);
            } while (c <= 5);

            //while-loop
            int d = 1;
            while (d <= 5)
            {
                Console.WriteLine(d++);
            }
        }
    }
}
