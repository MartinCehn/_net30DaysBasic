﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7Method
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    MultiplicationTable(end: 5, start: 2);
        //    Console.ReadKey();
        //}
        //static void MultiplicationTable(int start, int end)
        //{
        //    for (int i = start; i <= end; i++)
        //    {
        //        for (int j = start; j <= end; j++)
        //        {
        //            Console.Write($"{i} * {j} = {i * j}\t");
        //        }
        //        Console.Write("\n");
        //    }
        //}

        static void Main(string[] args)
        {
            MultiplicationTable(2, end: 9);
            Console.ReadKey();
        }
        static void MultiplicationTable(int unused1, int unused2 = 3, int start = 5, int end = 8)
        {
            for (int i = start; i <= end; i++)
            {
                for (int j = start; j <= end; j++)
                {
                    Console.Write($"{i} * {j} = {i * j}\t");
                }
                Console.Write("\n");
            }
        }
    }
}
