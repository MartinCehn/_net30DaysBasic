﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY16Class5
{
    class Program
    {
        static void Main(string[] args)
        {
            var member = new { ID = 0, Names = new string[] { "Mio", "Miffy" } };
            foreach (var name in member.Names)
            {
                Console.WriteLine($"ID = {member.ID}, Name = {name}");
                Console.ReadKey();
            }
        }
    }
}
