﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY12Inheritance
{
    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        ClassB classB = new ClassB();
    //        classB.SetA(6);
    //        classB.PrintA();
    //        Console.ReadKey();
    //    }
    //}
    //class ClassA
    //{
    //    protected int a = 0;
    //    public void PrintA()
    //    {
    //        Console.WriteLine(a);
    //    }
    //}
    //class ClassB : ClassA
    //{
    //    public void SetA(int number)
    //    {
    //        a = number;
    //    }
    //}

    //繼承-1
    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Bird bird = new Bird();
    //        bird.Eat();
    //        bird.Sleep();
    //        bird.Fly();
    //        Fish fish = new Fish();
    //        fish.Eat();
    //        fish.Sleep();
    //        fish.Swim();
    //        Console.ReadKey();
    //    }
    //}
    //class Animal
    //{
    //    public void Eat()
    //    {
    //        Console.WriteLine("進食");
    //    }
    //    public void Sleep()
    //    {
    //        Console.WriteLine("閉眼睡覺");
    //    }
    //}
    //class Bird : Animal
    //{
    //    public void Fly()
    //    {
    //        Console.WriteLine("飛行");
    //    }
    //}
    //class Fish : Animal
    //{
    //    public void Swim()
    //    {
    //        Console.WriteLine("游泳");
    //    }
    //}

    //繼承-2
    class Program
    {
        static void Main(string[] args)
        {
            Bird bird = new Bird();
            bird.Eat();
            bird.Sleep();
            bird.Fly();
            Fish fish = new Fish();
            fish.Eat();
            fish.Sleep();
            fish.Swim();
            Console.ReadKey();
        }
    }
    class Animal
    {
        public void Eat()
        {
            Console.WriteLine("進食");
        }
        public virtual void Sleep()
        {
            Console.WriteLine("閉眼睡覺");
        }
    }
    class Bird : Animal
    {
        public void Fly()
        {
            Console.WriteLine("飛行");
        }
    }
    class Fish : Animal
    {
        public void Swim()
        {
            Console.WriteLine("游泳");
        }
        public override void Sleep()
        {
            Console.WriteLine("開眼睡覺");
        }
    }
}
